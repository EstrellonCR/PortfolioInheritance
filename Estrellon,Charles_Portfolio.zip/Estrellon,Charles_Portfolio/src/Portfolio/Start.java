package Portfolio;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Window.Type;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
public class Start extends JFrame{

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Start frame = new Start();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Start() {
		setType(Type.UTILITY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(90, 90, 960, 564);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton btnNewButton = new JButton("About Me");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setForeground(new Color(128, 64, 64));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setFocusable(false);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				AboutMe me = new AboutMe();
				me.setVisible(true);
				me.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton.setBounds(417, 285, 107, 40);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Personal Info");
		btnNewButton_1.setBackground(new Color(255, 255, 255));
		btnNewButton_1.setFocusable(false);
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				PersonalInfo infos = new PersonalInfo();
				infos.setVisible(true);
				infos.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 12));
		btnNewButton_1.setForeground(new Color(128, 64, 64));
		btnNewButton_1.setBounds(560, 286, 107, 40);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Hobbies");
		btnNewButton_2.setBackground(new Color(255, 255, 255));
		btnNewButton_2.setFocusable(false);
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				Hobbies hob = new Hobbies();
				hob.setVisible(true);
				hob.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton_2.setForeground(new Color(128, 64, 64));
		btnNewButton_2.setBounds(698, 287, 107, 40);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Talent/Skills");
		btnNewButton_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton_3.setBackground(new Color(255, 255, 255));
		btnNewButton_3.setFocusable(false);
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				TalentsSkills ts = new TalentsSkills();
				ts.setVisible(true);
				ts.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_3.setForeground(new Color(128, 64, 64));
		btnNewButton_3.setBounds(486, 364, 107, 40);
		contentPane.add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Education");
		btnNewButton_4.setFont(new Font("Tahoma", Font.PLAIN, 10));
		btnNewButton_4.setBackground(new Color(255, 255, 255));
		btnNewButton_4.setFocusable(false);
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				EducationalBackground eb = new EducationalBackground();
				eb.setVisible(true);
				eb.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton_4.setForeground(new Color(128, 64, 64));
		btnNewButton_4.setBounds(627, 364, 107, 40);
		contentPane.add(btnNewButton_4);
		

		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\charles\\Downloads\\NEW1.png"));
		lblNewLabel.setBounds(0, 0, 946, 522);
		contentPane.add(lblNewLabel);
	}
}
