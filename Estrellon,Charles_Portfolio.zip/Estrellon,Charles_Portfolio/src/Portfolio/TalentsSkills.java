package Portfolio;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Window.Type;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

public class TalentsSkills extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TalentsSkills frame = new TalentsSkills();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TalentsSkills() {
		setType(Type.UTILITY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 960, 572);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 960, 540);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("Homepage");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				Start back = new Start();
				back.setVisible(true);
				back.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNewButton.setFocusable(false);
		btnNewButton.setForeground(new Color(128, 64, 64));
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNewButton.setBounds(98, 468, 121, 36);
		panel.add(btnNewButton);
		
		JButton btnNextPage = new JButton("Next Page");
		btnNextPage.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) { // for clicking the enter button.
				EducationalBackground nxt = new EducationalBackground();
				nxt.setVisible(true);
				nxt.setLocationRelativeTo(null);
				dispose();
			}
		});
		btnNextPage.setForeground(new Color(128, 64, 64));
		btnNextPage.setFont(new Font("Tahoma", Font.PLAIN, 14));
		btnNextPage.setFocusable(false);
		btnNextPage.setBounds(723, 466, 121, 41);
		panel.add(btnNextPage);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\charles\\Downloads\\Nude Beige Minimalist Creative Portfolio Coach Feminine  (1)\\5.png"));
		lblNewLabel.setBounds(0, 0, 950, 540);
		panel.add(lblNewLabel);
	}

}
